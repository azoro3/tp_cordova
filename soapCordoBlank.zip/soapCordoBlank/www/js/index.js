var env = "browser";
var url = "";
var prefix ="";
var Latitude = undefined;
var Longitude = undefined;


/*************************************************************************
 *                                Partie SOAP
 * ***********************************************************************/
var book = ' '; // TO-DO: écrire la lettre a envoyer au web servi e


$( "#soap" ).click(function() {
    if(env=="browser"){
        url = "http://localhost:8080/ws/";
        prefix = "ns2\\:";
    }else{
        url =  "http://10.0.2.2:8080/ws/";
        prefix = "";
    }
    var bookSend = book.replace("toReplace",$("#bookNameSearch").val());
    $.ajax({
        url: url , 
        type: "POST",
        xhrFields: {
            withCredentials: true
        }, 
        dataType: "xml", 
        data: bookSend, 
        contentType: "text/xml",
        success: OnSuccess, 
        error: OnError
    });
    return false;   
});
function OnSuccess(data, status)
{

    //TO-DO: afficher les informations recu 
};

function OnError(request, status, error)
{ 
    console.log(request);
    console.log("request");
    console.log(status); 
    console.log("status");
    console.log(error);
    console.log("error");
};

function displayResult(test){
    if(test){
        $("#mySoapResponse").removeAttr("hidden");
    }else{
        $("#mySoapResponse").attr("hidden","true");
        $("#map").attr("hidden","true");
    }
    
}


/****************************************************************
 *                  Partie Google maps
 ****************************************************************/
function getMapLocation() {

    navigator.geolocation.getCurrentPosition
    (onMapSuccess, onMapError, { enableHighAccuracy: true });
}
var onMapSuccess = function (position) {
    getMap(Latitude, Longitude);
}

function getMap(latitude, longitude) {

    // TO-DO afficher la BU dans GOOGLE-MAPS

    //[Optionnel] calculer l'intinéraire entre la bu et le telephone
}


var onMapWatchSuccess = function (position) {

    var updatedLatitude = position.coords.latitude;
    var updatedLongitude = position.coords.longitude;

    if (updatedLatitude != Latitude && updatedLongitude != Longitude) {

        Latitude = updatedLatitude;
        Longitude = updatedLongitude;

        getMap(updatedLatitude, updatedLongitude);
    }
}

// Error callback

function onMapError(error) {
    console.log('code: ' + error.code + '\n' +
        'message: ' + error.message + '\n');
}

// Watch your changing position

function watchMapPosition() {
    return navigator.geolocation.watchPosition
    (onMapWatchSuccess, onMapError, { enableHighAccuracy: true });
}
